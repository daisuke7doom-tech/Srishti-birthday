Srishti birthday website — Version 6.4

Keep index.html and birthday-song.mp3 together in the same folder.
For GitHub Pages, upload both files to the repository root.
